package com.example.curebytes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    private Button medicineReminderButton;
    private Button nearestPharmacyButton;
    private Button bookAppointmentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize buttons
        medicineReminderButton = findViewById(R.id.button_medicine_reminder);
        nearestPharmacyButton = findViewById(R.id.button_nearest_pharmacy);
        bookAppointmentButton = findViewById(R.id.button_book_appointment);

        // Set click listeners
        medicineReminderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Medicine Reminder Activity
                Intent intent = new Intent(HomeActivity.this, MedicineReminderActivity.class);
                startActivity(intent);
            }
        });

        nearestPharmacyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Nearest Pharmacy Activity
                Intent intent = new Intent(HomeActivity.this, NearestPharmacyActivity.class);
                startActivity(intent);
            }
        });

        bookAppointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Book Appointment Activity
                Intent intent = new Intent(HomeActivity.this, BookAppointmentActivity.class);
                startActivity(intent);
            }
        });
    }
}

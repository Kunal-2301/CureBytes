package com.example.curebytes;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
public class BookAppointmentActivity extends AppCompatActivity{
    private Spinner spinnerDoctor;
    private Button btnSelectDate, btnSelectTime, btnConfirmAppointment;
    private String selectedDoctor, selectedDate, selectedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment);  // appointment.xml

        // Initialize the UI elements
        spinnerDoctor = findViewById(R.id.spinner_doctor);
        btnSelectDate = findViewById(R.id.btn_select_date);
        btnSelectTime = findViewById(R.id.btn_select_time);
        btnConfirmAppointment = findViewById(R.id.btn_confirm_appointment);

        // Set up the Doctor Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.doctors_array,  // Assuming you have a string-array in strings.xml
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDoctor.setAdapter(adapter);

        // Handle Doctor selection
        spinnerDoctor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedDoctor = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedDoctor = null;
            }
        });

        // Set up Date Picker
        btnSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        // Set up Time Picker
        btnSelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        // Handle Confirm Appointment button click
        btnConfirmAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateAppointment()) {
                    // Show confirmation toast
                    String confirmationMessage = "Appointment with Dr. " + selectedDoctor +
                            " on " + selectedDate + " at " + selectedTime + " is confirmed!";
                    Toast.makeText(BookAppointmentActivity.this, confirmationMessage, Toast.LENGTH_LONG).show();

                    // You can add code here to store appointment data to a database or an API call
                } else {
                    Toast.makeText(BookAppointmentActivity.this, "Please fill in all details", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to show Date Picker dialog
    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, month1, dayOfMonth) -> {
                    selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                    btnSelectDate.setText(selectedDate);  // Update button text
                }, year, month, day);
        datePickerDialog.show();
    }

    // Method to show Time Picker dialog
    private void showTimePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, hourOfDay, minute1) -> {
                    selectedTime = hourOfDay + ":" + (minute1 < 10 ? "0" + minute1 : minute1);  // Format the time
                    btnSelectTime.setText(selectedTime);  // Update button text
                }, hour, minute, true);
        timePickerDialog.show();
    }

    // Validate that all required fields are filled
    private boolean validateAppointment() {
        return selectedDoctor != null && selectedDate != null && selectedTime != null;
    }
}

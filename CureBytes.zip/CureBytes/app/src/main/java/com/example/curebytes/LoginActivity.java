package com.example.curebytes;
public class LoginActivity {

    // Hardcoded valid credentials
    private final String validEmail = "user@example.com";
    private final String validPassword = "password123";

    // Method to validate the login credentials
    public boolean validateCredentials(String email, String password) {
        return email.equals(validEmail) && password.equals(validPassword);
    }
}